@extends('layouts.layout')
@section('content')
<div class="row">
  <section class="content">
    <div class="col-md-8 col-md-offset-2">
    @if (count($errors) > 0)
			<div class="alert alert-danger">
				<strong>Error!</strong> Revise los campos obligatorios.<br><br>
				<ul>
					@foreach ($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
			@endif
			@if(Session::has('success'))
			<div class="alert alert-info">
				{{Session::get('success')}}
			</div>
			@endif

      <div class="panel panel-default">
        <div class="panel-body">
          <div class="pull-left"><h3>Usuarios</h3></div>
          <div class="pull-right">
            <div class="btn-group">
              <a href="{{ route('Usuario.index') }}" class="btn btn-info" >Añadir Usuario</a>
            </div>
          </div>
          <div class="table-container">
            <table id="mytable" class="table table-bordred table-striped">
             <thead>
               <th>Número</th>
               <th>Nombre</th>
               <th>Apellido Paterno</th>
               <th>Apellido Materno</th>
               <th>Fecha de nacimiento</th>
               <th>Ingreso Anual</th>
             </thead>
             <tbody>
    
              @if($usuarios->count())  
              @foreach($usuarios as $usuario)  
              <tr>
                <td>{{$usuario->idUsuario}}</td>
                <td>{{$usuario->nombre}}</td>
                <td>{{$usuario->aPaterno}}</td>
                <td>{{$usuario->aMaterno}}</td>

              @endforeach  
              @if($usuarios->count())          
              @foreach($datos as $dato)  
                  <td>{{$dato->fechaNac}}</td>
                  <td>{{$dato->IngresoAnual}}</td> 
              @endforeach 
              @endif
              </tr>
               @else
               <tr>
                <td colspan="8">No hay registro !!</td>
              </tr>
              @endif
            </tbody>
 
          </table>
        </div>
      </div>
      <!-- {{ $usuarios->links() }} -->
    </div>
  </div>
</section>
 
@endsection