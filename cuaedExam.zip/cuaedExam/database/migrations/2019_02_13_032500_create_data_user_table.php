<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDataUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('data_user', function (Blueprint $table) {
            $table->increments('idRegistro');
            $table->date('fechaNac');
            $table->decimal('IngresoAnual',100,2);
            $table->integer('fk_idUsuario')->unsigned()->default('1');
            $table->foreign('fk_idUsuario')->references('idUsuario')->on('user_register')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('data_user');
    }
}
