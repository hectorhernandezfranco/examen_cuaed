<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class userRegister extends Model
{
    protected $table="user_register";
    protected $fillable = ['idUsuario','nombre', 'aPaterno', 'aMaterno'];
}

