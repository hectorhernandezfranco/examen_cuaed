<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class data_user extends Model
{
    //
}
