<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class userData extends Model
{
    protected $table="data_user";
    protected $fillable = ['idRegistro','fechaNac', 'IngresoAnual', 'fk_idUsuario'];
}


