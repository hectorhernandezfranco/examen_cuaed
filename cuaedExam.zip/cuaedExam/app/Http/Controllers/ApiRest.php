<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ApiRest extends Controller
{
    public function Registro(){
        try {
            DB::connection()->getPdo();
        } catch (\Exception $e) {
            die("Could not connect to the database.  Please check your configuration. error:" . $e );
        }
    }
}
