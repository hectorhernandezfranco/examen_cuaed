<?php $__env->startSection('content'); ?>
<div class="row">
  <section class="content">
    <div class="col-md-8 col-md-offset-2">
    <?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<strong>Error!</strong> Revise los campos obligatorios.<br><br>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
			<?php if(Session::has('success')): ?>
			<div class="alert alert-info">
				<?php echo e(Session::get('success')); ?>

			</div>
			<?php endif; ?>

      <div class="panel panel-default">
        <div class="panel-body">
          <div class="pull-left"><h3>Usuarios</h3></div>
          <div class="pull-right">
            <div class="btn-group">
              <a href="<?php echo e(route('Usuario.index')); ?>" class="btn btn-info" >Añadir Usuario</a>
            </div>
          </div>
          <div class="table-container">
            <table id="mytable" class="table table-bordred table-striped">
             <thead>
               <th>Número</th>
               <th>Nombre</th>
               <th>Apellido Paterno</th>
               <th>Apellido Materno</th>
               <th>Fecha de nacimiento</th>
               <th>Ingreso Anual</th>
             </thead>
             <tbody>
    
              <?php if($usuarios->count()): ?>  
              <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
              <tr>
                <td><?php echo e($usuario->idUsuario); ?></td>
                <td><?php echo e($usuario->nombre); ?></td>
                <td><?php echo e($usuario->aPaterno); ?></td>
                <td><?php echo e($usuario->aMaterno); ?></td>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
              <?php if($usuarios->count()): ?>          
              <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                  <td><?php echo e($dato->fechaNac); ?></td>
                  <td><?php echo e($dato->IngresoAnual); ?></td> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
              <?php endif; ?>
              </tr>
               <?php else: ?>
               <tr>
                <td colspan="8">No hay registro !!</td>
              </tr>
              <?php endif; ?>
            </tbody>
 
          </table>
        </div>
      </div>
      <!-- <?php echo e($usuarios->links()); ?> -->
    </div>
  </div>
</section>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>